import React, { useEffect } from "react";
import { Suspense } from "react";
import { LoadingOutlined } from "@ant-design/icons";
import { Route, Routes, useLocation } from "react-router-dom";
const PageNotFound = React.lazy(() => import("../PageNotFound/Index"));
import ScrollToTop from "../../Component/ScrollToTop";

const Index = () => {

  return (
    <>
      <ScrollToTop />
      <Suspense
        fallback={
          <div className="text-center mt-10">
            <LoadingOutlined />
          </div>
        }
      >
        <Routes>
          <Route path="*" element={<PageNotFound />} /> {/* Catch-all 404 */}
          {/* <Route path="/" element={<LandingPage />} /> */}

        </Routes>
      </Suspense>
    </>
  );
};
export default Index;
