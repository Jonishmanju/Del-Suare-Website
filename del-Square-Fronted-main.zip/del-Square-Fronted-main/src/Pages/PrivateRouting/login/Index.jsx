import React from "react";
import Reviews from "../../PrivateRouting/review/component/Reviews";
import LoginPage from "./component/LoginPage";
import Layout from "../layouts/Index";

function index() {
  return (
    <>
      <>
        <LoginPage />
      </>
    </>
  );
}

export default index;
