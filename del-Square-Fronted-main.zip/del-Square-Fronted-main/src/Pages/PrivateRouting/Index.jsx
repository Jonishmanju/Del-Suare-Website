import React, { useEffect } from "react";
import { Suspense } from "react";
import { LoadingOutlined } from "@ant-design/icons";
import { Route, Routes, useLocation, useNavigate } from "react-router-dom";
import PageNotFound from "../PageNotFound/Index";
import ScrollToTop from "../../Component/ScrollToTop";


const Index = () => {

  return (
    <>
      <ScrollToTop />
      <Suspense
        fallback={
          <div className="text-center mt-10">
            <LoadingOutlined />
          </div>
        }
      >
        <Routes>
          <Route path="/" element={
            <div className="text-center p-8">
              <h2 className="text-2xl font-bold mb-4">Admin Dashboard</h2>
              <p>Welcome to the admin panel. Use the sidebar to navigate.</p>
            </div>
          } />
          <Route path="*" element={<PageNotFound />} /> {/* Catch-all 404 */}
        </Routes>
      </Suspense>
    </>
  );
};
export default Index;
