export const ZEGO_CONFIG = {
  appID: 891706866, // Replace with your Zego App ID from console
  serverSecret: "d33485f59d321911c1651498d6888f4e", // Replace with your server secret
};
